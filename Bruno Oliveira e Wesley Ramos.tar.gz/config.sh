#!/bin/bash
arp -s 10.0.1.1 00:00:00:00:01:01 &> /dev/null
arp -s 10.0.1.2 00:00:00:00:01:02 &> /dev/null
