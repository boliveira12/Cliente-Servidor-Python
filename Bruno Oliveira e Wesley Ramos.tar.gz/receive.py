#!/usr/bin/env python3
import sys
import socket

serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serverSocket.bind(('', 8080))
serverSocket.listen(1)
while True:
    print ('Ready to serve...')
    connectionSocket, addr = serverSocket.accept()
    try:
        mensagem = connectionSocket.recv(1024).decode()
        if 'GET' in mensagem:
            connectionSocket.send('Hello World vindo do HTTP GET!'.encode())
        elif 'POST' in mensagem: 
            print (mensagem)
            filename = mensagem.split()[1]
            connectionSocket.send('HTTP/1.0 200 OK\r\n\r\n'.encode())               
        connectionSocket.close()
    except IOError:
        connectionSocket.send('404 Not Found')
        connectionSocket.close()
serverSocket.close() 