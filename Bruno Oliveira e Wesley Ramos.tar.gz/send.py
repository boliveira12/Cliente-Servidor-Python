#!/usr/bin/env python3
import sys
import socket

ip = input('digite o ip de conexao: ') 
opt = input('Voce deseja fazer um GET digite 1, deseja fazer um POST digite 2.')
port = 8080
mensagem = ""
addr = (ip,port) 
if opt == '1':
        mensagem = "GET / HTTP/1.1\r\nHost: {}\r\n\r\n".format(ip)
if opt == '2':
        mensagem = "POST / HTTP/1.1\r\nHost: {}\r\n\r\n".format(ip)
        body = ("Hello World vindo do HTTP POST!")
        mensagem = mensagem + body
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(addr)
client_socket.send(mensagem.encode("utf-8"))
resposta = client_socket.recv(1024).decode()
print ('resposta:', resposta)
client_socket.close()